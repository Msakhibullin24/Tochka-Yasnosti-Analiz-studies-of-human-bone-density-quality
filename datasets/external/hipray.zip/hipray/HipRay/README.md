# HipRay (hip joint radiographs)

Part of the FleXray data release. Repackaged from the original distribution at
https://data.mendeley.com/datasets/zm6bxzhmfz/1 under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

**Citation:** Gut, D. X-ray images of the hip joints. Mendeley Data, V1 (2021). doi:10.17632/zm6bxzhmfz.1

## Contents

- 139 samples (test: 21, train: 97, val: 21); one image and one label per sample.
- `images/*.png`: 16-bit grayscale PNG, intensities in [0, 65535] map linearly to [0, 1].
- `labels/`: dense index map (PNG). Label ids/channels:
- `0`: background
- `1`: femurs
- `2`: hips
- `dataset.yml`: `fxr-dataset` manifest (schema version 1). Splits are the
  ones used in the FleXray paper; `metadata.original_shape` is the source image shape.

## Preprocessing

Every image was min-max normalized to [0, 1] per image, padded to a square with zeros
(centered) and resized to 256 x 256 (area interpolation for images, nearest for labels). Labels were remapped from the
source annotation to the dataset-native names listed above; the FleXray package maps
those names into its label protocol at training time.

## Usage

```bash
pip install flexray
fxr-dataset validate dataset.yml
fxr-dataset pack dataset.yml /data/flexray/HipRay
```
